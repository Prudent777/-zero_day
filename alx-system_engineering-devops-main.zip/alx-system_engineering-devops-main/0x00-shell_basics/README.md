0x00. Shell, basics

